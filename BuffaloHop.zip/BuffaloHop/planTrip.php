<?php
// Assuming you have a database connection established
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buffalohop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve values from the form
$departure = $_POST['Departure']; // Corrected variable name
$destination = $_POST['Arrival']; // Corrected variable name
 
// Perform your trip planning logic here if needed

// Redirect to the Cost To Ride page
header("Location: cost_to_ride.php?Departure=$departure&Arrival=$destination");
exit();
?>
