<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .buy-ticket-btn {
            display: inline-block;
            padding: 6px 12px;
            text-align: center;
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            border: 1px solid #4CAF50;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Time</th>
            <th>Departure</th>
            <th>Arrival</th>
            <th>Price (Rands)</th>
            <th>Action</th>
        </tr>
        <?php
        // Provided data with times
        $data = [
            ['05:45', 'City Hall Oxford Rd', 'De Haviland Ave', 15.00],
            ['06:10', 'De Haviland Ave', 'Wetzler Rd', 25.00],
            ['06:50', 'Wetzler Rd', 'Oxford Market Square', 15.00],
            ['07:00', 'Oxford Market Square', 'Beach Rd Nahoon', 30.00],
            ['07:45', 'Beach Rd Nahoon', 'Currie Str Quigney', 20.00],
            ['14:00', 'Grens High McJannet', 'City Hall Oxford Street', 15.00],
            ['14:25', 'Ackermans Oxford Street', 'Morrison Rd', 10.00]
        ];

        // Display data in the table
        foreach ($data as $index => $row) {
            echo "<tr>
                    <td>{$row[0]}</td>
                    <td>{$row[1]}</td>
                    <td>{$row[2]}</td>
                    <td>R&nbsp;{$row[3]}</td>
                    <td><a class='buy-ticket-btn' href='BuyTickets.html?time={$row[0]}&departure={$row[1]}&arrival={$row[2]}&price={$row[3]}'>Buy Ticket</a></td>
                </tr>";
        }
        ?>
    </table>
</body>
</html>
