
        

        function planTrip() {
            var departure = document.getElementById("departure").value;
            var destination = document.getElementById("destination").value;
            // You can add your trip planning logic here
            alert("Planning trip from " + departure + " to " + destination);}

            // script.js
document.addEventListener("DOMContentLoaded", function() {
    // Get tab buttons and tab content
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    // Function to switch tabs
    function switchTab(tabIndex) {
        // Hide all tab contents
        tabContents.forEach(content => {
            content.style.display = 'none';
        });

        // Show the selected tab content
        tabContents[tabIndex].style.display = 'block';
    }

    // Add click event listeners to the tab buttons
    tabButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            // Switch to the clicked tab
            switchTab(index);

            // Add active class to the clicked tab button and remove it from others
            tabButtons.forEach(btn => {
                btn.classList.remove('active');
            });
            button.classList.add('active');
        });
    });

    // Initially, show the first tab
    switchTab(0);
});

  

        const menuIcon = document.getElementById("menuIcon");
        menuIcon.addEventListener("click", () => {
            document.querySelector('.navbar').classList.toggle('active');
        });
        
        <script>
            // Smooth scrolling for anchor links
            $(document).ready(function () {
                // Add smooth scrolling to all links
                $("a").on('click', function (event) {
                    // Make sure this.hash has a value before overriding default behavior
                    if (this.hash !== "") {
                        // Prevent default anchor click behavior
                        event.preventDefault();
    
                        // Store hash
                        var hash = this.hash;
    
                        // Using jQuery's animate() method to add smooth page scroll
                        // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
                        $('html, body').animate({
                            scrollTop: $(hash).offset().top
                        }, 800, function () {
                            // Add hash (#) to URL when done scrolling (default click behavior)
                            window.location.hash = hash;
                        });
                    } // End if
                })
            
            });
        </script>