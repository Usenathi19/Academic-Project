<?php
// Assuming you have a database connection established
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buffalohop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process login form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Retrieve user information
    $getUserSQL = "SELECT * FROM customer_info WHERE username = '$username'";
    $result = $conn->query($getUserSQL);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify the entered password against the hashed password in the database
        if (password_verify($password, $row['password'])) {
            // Start the session and store user information
            session_start();
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];

            echo "Login successful. Welcome, $username! <a href='tickets.php'>Print Ticket</a>";
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "User not found. <a href='register.php'>Register</a>";
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
