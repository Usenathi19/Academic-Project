<?php
session_start();

if (isset($_SESSION['user_id'])) {
    echo "Welcome, " . $_SESSION['username'] . "!<br>";
    echo "<a href='generate_ticket.php'>Print Ticket</a>";
} else {
    echo "User not logged in.";
}
?>

