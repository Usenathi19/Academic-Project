<?php
// Assuming you have a database connection established
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buffalohop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start the session
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve user information
    $getUserSQL = "SELECT * FROM customer_info WHERE id = $userId"; // Adjust the table name
    $result = $conn->query($getUserSQL);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Generate a unique ticket number (you may want to implement a more robust method)
        $ticketNumber = uniqid();

        // Retrieve ticket information from the database (including "Prices")
        $getTicketSQL = "SELECT * FROM routes ORDER BY RAND() LIMIT 1"; // Adjust the query as needed
        $ticketResult = $conn->query($getTicketSQL);

        if ($ticketResult->num_rows > 0) {
            $ticketRow = $ticketResult->fetch_assoc();

            // Display ticket information
            echo "<h2>Ticket Information</h2>";
            echo "<strong>Name:</strong> {$row['username']}<br>";
            echo "<strong>Departure:</strong> {$ticketRow['Departure']}<br>";
            echo "<strong>Arrival:</strong> {$ticketRow['Arrival']}<br>";

            // Check if "Price" key exists in the $ticketRow array and is not null
            if (isset($ticketRow['Price']) && $ticketRow['Price'] !== null) {
                echo "<strong>Price:</strong> R{$ticketRow['Price']}<br>";
            } else {
                echo "<strong>Price:</strong> Price information not available<br>";
            }

            echo "<strong>Ticket Number:</strong> $ticketNumber<br>";

            // Display the current date and time
            $currentDateTime = date('Y-m-d H:i:s');
            echo "<strong>Current Date and Time:</strong> $currentDateTime<br>";

            // Register the ticket number in the database
            $registerTicketSQL = "INSERT INTO tickets (user_id, ticket_number) VALUES ($userId, '$ticketNumber')";
            $conn->query($registerTicketSQL);
        } else {
            echo "Error retrieving ticket information.";
        }
    } else {
        echo "User not found.";
    }
} else {
    echo "User not logged in.";
}

$conn->close();
?>
