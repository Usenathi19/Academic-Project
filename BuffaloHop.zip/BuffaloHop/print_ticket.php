<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ticketNumber = $_POST["ticket_number"];

    // Retrieve ticket information from the database based on the ticket number
    // Adjust the query according to your database structure
    $getTicketSQL = "SELECT * FROM tickets WHERE ticket_number = '$ticketNumber'";
    // Execute the query and fetch the result
    // Display the ticket information
    // You may also generate a PDF or use other methods to "print" the ticket
    echo "Ticket Number: $ticketNumber<br>";
    // Display other ticket details based on your database structure
} else {
    echo "Invalid request.";
}
?>
